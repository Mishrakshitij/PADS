from __future__ import print_function
from collections import deque
from tqdm import tqdm
import pandas as pd
import os
import matplotlib.pyplot as plt

cur_dir = os.getcwd()

from rl.pg_reinforce import PolicyGradientREINFORCE
import tensorflow as tf
import numpy as np
import argparse

from env import Enviroment
from user import User

import tensorflow.compat.v1 as tf
tf.disable_v2_behavior()


FLAGS = None
parser = argparse.ArgumentParser()
parser.add_argument('--sample', type=str)
parser.add_argument('--num_epoch', type=int)
parser.add_argument('--restore', type=str)
parser.add_argument('--save_dir', type=str)
parser.add_argument('--model_dir', type=str)
FLAGS, unparsed = parser.parse_known_args()

actionID_to_template = {
    0: "Hello. I'm an automated dialogue system that can give you Bus schedule information. To start with, Please, tell us, where do you want to go?",
    1: "Thank you! for providing us your <a>, Please, also tell us Where would you like to leave from?",
    2: "Thank you! Your source and destiantion are <a>, <d>. Please, also provide us the time at which you want to travel",
    3: "Sorry, for inconvenience. Let me look that up for you. There is a <route> leaving from <departure> to <arrival> at <time>.",
    4: "Let me look that up for you. Sorry, there is no result that matches your request. We hope, we had been of help.",
    5: "where do you want to go?",
    6: "where are you leaving from?",
    7: "what time do you want to travel?"
}

sess = tf.Session()

optimizer = tf.train.RMSPropOptimizer(learning_rate=0.0001, decay=0.9)
writer = tf.summary.FileWriter("/tmp/{}-experiment-3".format("my_data"))

SAVE_DIR = cur_dir + "/" + "FLAGS.model_dir"
HIDDEN_DIM = 32
CLEAN_PROB = 0.9
num_entities = 5    # <d>, <a>, <time>, <uncovered_d>, <uncovered_a>
num_actions  = 8    # number of action templates, temporarily 6
state_dim = num_entities + num_actions  # presenecs of 3 entities +  one-hot-vec for last_action_taken

user = User(cur_dir + "/data/actionID_to_template.json",
            num_entity=5, num_action=num_actions, clean_prob=CLEAN_PROB)
env = Enviroment(state_dim, num_actions, num_entities, user, agent=None)

def policy_network_simple(states):
    # define policy neural network
    W1 = tf.get_variable("W1", [state_dim, 20],
                         initializer=tf.random_normal_initializer())
    b1 = tf.get_variable("b1", [20],
                         initializer=tf.constant_initializer(0))
    h1 = tf.nn.tanh(tf.matmul(states, W1) + b1)
    W2 = tf.get_variable("W2", [20, num_actions],
                         initializer=tf.random_normal_initializer(stddev=0.1))
    b2 = tf.get_variable("b2", [num_actions],
                         initializer=tf.constant_initializer(0))
    p = tf.matmul(h1, W2) + b2
    return p

def policy_network(states, initial_rnn_state, bit_vec):
    # define policy neural network
    rnn_cell = tf.compat.v1.nn.rnn_cell.LSTMCell(HIDDEN_DIM, state_is_tuple=True)
    rnn_output, rnn_state = rnn_cell(states, initial_rnn_state)

    dense_output = tf.layers.dense(rnn_output, num_actions, activation=None)
    masked_output = dense_output * bit_vec

    return masked_output, rnn_state

def run_one_dialog(env, pg_reinforce):
    # initialize
    state = env.reset()
    total_rewards = 0
    prev_rnn_states = [np.zeros((1, HIDDEN_DIM)), np.zeros((1, HIDDEN_DIM))]
    bit_vector = [1, 1, 1, 0, 0, 1, 1, 1]
    dialog_len = 0
    for t in range(MAX_STEPS):
        dialog_len += 1
        # env.render()
        if env.queryable():
            bit_vector[3], bit_vector[4]= env.query_status()
        # print(bit_vector)
        # print("User: {}".format(env.user_action))
        action, prev_rnn_states = pg_reinforce.sampleAction(state[np.newaxis,:], prev_rnn_states, bit_vector)
        # print(prev_rnn_states)
        # print("System: {}".format(actionID_to_template[action]))
        next_state, reward, done = env.step(action, SAMPLE)

        # total_rewards += reward
        # reward = -10 if done else reward # normalize reward

        total_rewards += reward
        pg_reinforce.storeRollout(state, action, reward, prev_rnn_states, bit_vector)

        state = next_state
        if done: break
    env.not_in_sample()
    pg_reinforce.cleanUp()

    return total_rewards, dialog_len, env.success

pg_reinforce = PolicyGradientREINFORCE(sess,
                                       optimizer,
                                       policy_network,
                                       state_dim,
                                       num_actions,
                                       rnn_hidden_dim=HIDDEN_DIM,
                                       summary_writer=writer,
                                       discount_factor=0.9)

if FLAGS.restore == "yes":
    ckpt = tf.train.get_checkpoint_state('.')
    pg_reinforce.saver.restore(sess, ckpt.model_checkpoint_path)
    print("restore done")
MAX_EPISODES = FLAGS.num_epoch
if FLAGS.sample == "no":
    SAMPLE = False
else:
    SAMPLE = True
MAX_STEPS    = 15
NUM_TEST = 400
episode_history = deque(maxlen=100)
test_id = []
mean_reward_test = []
mean_len_test = []
mean_success_test = []
#for k in tqdm(range(0,20))
for i_episode in tqdm(range(MAX_EPISODES)):

    if (i_episode+1) % 200 == 0:
        reward_list = []
        dialogLen_list = []
        success_list = []
        for i_test in range(NUM_TEST):
            cur_reward, cur_dialogLen, cur_success = run_one_dialog(env, pg_reinforce)
            reward_list.append(cur_reward)
            dialogLen_list.append(cur_dialogLen)
            success_list.append(cur_success)
            print(cur_reward)
            print(cur_dialogLen)
            print(cur_success)
        mean_reward_test.append(np.mean(reward_list))
        mean_len_test.append(np.mean(dialogLen_list))
        mean_success_test.append(np.mean(success_list))
        test_id.append(i_episode)

    # initialize
    state = env.reset()
    total_rewards = 0
    prev_rnn_states = [np.zeros((1, HIDDEN_DIM)), np.zeros((1, HIDDEN_DIM))]
    bit_vector = [1, 1, 1, 0, 0, 1, 1, 1]


    for t in range(MAX_STEPS):
      # env.render()
        if env.queryable():
            bit_vector[3], bit_vector[4] = env.query_status()
        # print(bit_vector)
        print("User: {}".format(env.user_action))
        action, prev_rnn_states = pg_reinforce.sampleAction(state[np.newaxis,:], prev_rnn_states, bit_vector)
        # print(prev_rnn_states)
        print("System: {}".format(actionID_to_template[action]))
        next_state, reward, done = env.step(action, sample=SAMPLE)
        print("State: {}".format(next_state))
        print("bit_vec: {}".format(bit_vector))
        print("reward: {}".format(reward))

        # total_rewards += reward
        # reward = -10 if done else reward # normalize reward

        total_rewards += reward
        pg_reinforce.storeRollout(state, action, reward, prev_rnn_states, bit_vector)

        state = next_state
        if done: break
    # for i in xrange(len(pg_reinforce.))

    pg_reinforce.updateModel()

    episode_history.append(total_rewards)
    mean_rewards = np.mean(episode_history)

    print("Episode {}".format(i_episode))
    print("Finished after {} timesteps".format(t+1))
    print("Reward for this episode: {}".format(total_rewards))
    print("Average reward for last 100 episodes: {:.2f}".format(mean_rewards))
    print("\n\n\n")
    if mean_rewards >= 17 and len(episode_history) >= 100:
        print("Environment {} solved after {} episodes".format("simulation", i_episode+1))
        break
print(mean_reward_test)
test_history = zip(test_id, mean_reward_test, mean_len_test, mean_success_test)

test_results=pd.DataFrame(test_history, columns=["id", "reward", "len", "success"]).to_csv(cur_dir+"/"+FLAGS.save_dir, index=False)
# pg_reinforce.saver.save(sess, SAVE_DIR, write_meta_graph=False)
