from __future__ import division
import numpy as np
import pandas as pd
from numpy import random
import json
from collections import Counter
import os

cur_dir = os.getcwd()
sample_dir = cur_dir + "data/sample_from.csv"

actionID_to_template = {
    0: "Hello. I'm an automated dialogue system that can give you Bus schedule information. To start with, Please, tell us, where do you want to go?",
    1: "Thank you! for providing us your <a>, Please, also tell us Where would you like to leave from?",
    2: "Thank you! Your source and destiantion are <a>, <d>. Please, also provide us the time at which you want to travel",
    3: "Sorry, for inconvenience. Let me look that up for you. There is a <route> leaving from <departure> to <arrival> at <time>.",
    4: "Let me look that up for you. Sorry, there is no result that matches your request. We hope, we had been of help.",
    5: "where do you want to go?",
    6: "where are you leaving from?",
    7: "what time do you want to travel?"
   
}


sample_from = pd.read_csv('~/Downloads/RL_PADS_edits/sample_from_action_567_addition.csv', sep = ',')
class User(object):
    def __init__(self, actionID_template_dir, num_entity=5, num_action=8, clean_prob=0.8):
        self.num_entity = num_entity
        self.initial_action = None
        self.actionID_template_dir = actionID_template_dir
        self.id_to_entity = {
            0: "<d>",
            1: "<a>",
            2: "<time>",
            3: "<uncovered_d>",
            4: "<uncovered_a>",
            5: "<d>",
            6: "<a>",
            7: "<time>"
        }
        self.num_action = num_action
        with open(self.actionID_template_dir, "r") as fh:
            self.actionID_template = json.load(fh)
        # set initial goals
        self.goal = self.set_initial_goal()
        self.system_action = []
        self.not_in_sample = 0
        self.total_sample = 0
        self.clean_prob=clean_prob

    def set_initial_goal(self):
        """

        :return:
        """
        goal = {"departure": None,
                "arrival": None,
                "time": "<time>"
        }
        if random.randint(low=0, high=2, size=1)[0]:
            goal["departure"] = "<uncovered_d>"
        else:
            goal["departure"] = "<d>"
        if random.randint(low=0, high=2, size=1)[0]:
            goal["arrival"] = "<uncovered_a>"
        else:
            goal["arrival"] = "<a>"
        return goal


    def reset(self):
        """
        clean up the memory and come up with a new starting entity
        <d>, <a>, <time>, <uncovered_d>, <uncovered_a>
        self.user_action = self.user.reset()
        :return:
        """
        which_entity = random.randint(low=0, high=3, size=1)[0]
        # print "not in sample: ", self.not_in_sample/self.total_sample
        self.system_action = [] # clean up the history
        self.goal = self.set_initial_goal()
        self.not_in_sample = 0
        self.total_sample = 0
        return self.add_noise_to_response(self.goal[list(self.goal.keys())[which_entity]])
        # return self.goal[self.goal.keys()[which_entity]]

    def summarize_system_action(self):
        return Counter(self.system_action)

    def add_noise_to_response(self, res):
        clean = np.random.choice(range(2), p=[1-self.clean_prob, self.clean_prob])
        if clean:
            return res
        else:
            return ">NOISE<"

    def respond(self, agent_action, dialog_state, sample=False, rep_penalty=True):
        if sample:
            sample_acoustic_user_action = self.sample_based_on_history(agent_action)
        else:
            sample_acoustic_user_action = None

        if rep_penalty:
            if agent_action == 0 and (dialog_state[1] or dialog_state[4]): # "where do you want to go"
                return "You already asked/know that!", sample_acoustic_user_action
            if agent_action == 1 and (dialog_state[0] or dialog_state[3]):
                return "You already asked/know that!", sample_acoustic_user_action
            if agent_action == 2 and (dialog_state[2]):
                return "You already asked/know that!", sample_acoustic_user_action

            if agent_action == 5 and (dialog_state[1] or dialog_state[4]): # "where do you want to go"
                return "You already asked/know that!", sample_acoustic_user_action
            if agent_action == 6 and (dialog_state[0] or dialog_state[3]):
                return "You already asked/know that!", sample_acoustic_user_action
            if agent_action == 7 and (dialog_state[2]):
                return "You already asked/know that!", sample_acoustic_user_action


        self.system_action.append(agent_action) # log cur agent_action

        if agent_action == 0: # "where do you want to go?"
            response = self.add_noise_to_response(self.goal['arrival'])
            return response, sample_acoustic_user_action
        if agent_action == 1: # "where are you leaving from?"
            response = self.add_noise_to_response(self.goal['departure'])
            return response, sample_acoustic_user_action
        if agent_action == 2: # "what time do you want to travel?"
            response = self.add_noise_to_response(self.goal['time'])
            return response, sample_acoustic_user_action
        if agent_action == 3 and (dialog_state[0] and dialog_state[1] and dialog_state[2]): # only after the user has told the environment all the info
            return "thank you", sample_acoustic_user_action
        if agent_action == 4 and ((dialog_state[2] and dialog_state[0] and dialog_state[4]) or 
                                  (dialog_state[2] and dialog_state[1] and dialog_state[3]) or
                                  (dialog_state[2] and dialog_state[3] and dialog_state[4])):
            return "thank you", sample_acoustic_user_action
        
        if agent_action == 5: # "where do you want to go?"
            response = self.add_noise_to_response(self.goal['arrival'])
            return response, sample_acoustic_user_action
        if agent_action == 6: # "where are you leaving from?"
            response = self.add_noise_to_response(self.goal['departure'])
            return response, sample_acoustic_user_action
        if agent_action == 7: # "what time do you want to travel?"
            response = self.add_noise_to_response(self.goal['time'])
            return response, sample_acoustic_user_action
        # if agent_action == 5 and (3 in self.system_action or 4 in self.system_action):
        #     return "Good bye!"
        # if agent_action == 5 and ((3 not in self.system_action) and (4 not in self.system_action)):
        #     return "But we haven't finish yet!"
        return "That's not what I want!", sample_acoustic_user_action

    def sample_based_on_history(self, agent_action):
        self.total_sample += 1
        system_action_history = self.summarize_system_action()
        
        query_expr = " myAction == " + str(agent_action) + " and total_act0 == " + str(system_action_history[0]) + \
                        " and total_act1 == " + str(system_action_history[1]) + " and total_act2 == " + str(system_action_history[2]) + \
                        " and total_act3 == " + str(system_action_history[3]) + " and total_act4 == " + str(system_action_history[4]) + \
                        " and total_act5 == " + str(system_action_history[5]) + " and total_act6 == " + str(system_action_history[6]) + \
                        " and total_act7 == " + str(system_action_history[7])

        sample_from_subset = sample_from.query(query_expr)
        features = [u'interruption', u'interruption_total', u'dtmf', u'dtmf_total',
                    u'repeat', u'repeat_total', u'start_over', u'start_over_total']
        if sample_from_subset.shape[0]:
            r_id = np.random.randint(low=0, high=sample_from_subset.shape[0], size=1)
            return sample_from_subset.iloc[r_id][features]
        else:
            self.not_in_sample += 1
            return [0] * 8
            # r_id = np.random.randint(low=0, high=sample_from.shape[0], size=1)
            # return sample_from.iloc[r_id][features]



