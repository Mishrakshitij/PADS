from __future__ import division
import numpy as np
from util import oneHotLabel
import pickle
import os


from simpletransformers.classification import ClassificationModel, ClassificationArgs
import pandas as pd
import logging

logging.basicConfig(level=logging.INFO)
transformers_logger = logging.getLogger("transformers")
transformers_logger.setLevel(logging.WARNING)

model = ClassificationModel(
    "distilbert", "outputs_dstc1", use_cuda=False
)

cur_dir = os.getcwd()
# sentiment_model_dir = cur_dir + "/../sentiment_model"

# with open(sentiment_model_dir, "r") as fh:
    # sentiment_model = pickle.load(fh)

class Enviroment(object):
    """
    dialog manager,
    state = [<d>, <a>, <time>, <uncovered_d>, <uncovered_a>, last_action_1_hot]
    """
    def __init__(self, state_dim, num_action, num_entity, user, agent=None):
        self.state_dim = state_dim
        self.num_action = num_action
        self.num_entity = num_entity

        self.user_action = None
        self.last_agent_action = None
        self.user = user
        self.agent = agent
        self.state_maintained = np.zeros(self.state_dim)
        self.done = False
        self.success = None

    def reset(self):
        # state = env.reset()
        self.state_maintained = np.zeros(self.state_dim)
        self.done = False
        if self.agent:
            self.agent.reset()
        self.user_action = self.user.reset()
        self.maintain_states()
        return self.state_maintained

    # def render(self):
    #     # env.render()
    def queryable(self):
        if (self.state_maintained[0] or self.state_maintained[3]) and self.state_maintained[2] and (self.state_maintained[1] or self.state_maintained[4]):
            return True
        else:
            return False

    def query_status(self):
        if self.state_maintained[0] and self.state_maintained[1]:
            return 1, 0
        else:
            return 0, 1

    def maintain_states(self):
        """
        state = [<d>, <a>, <time>, <uncovered_d>, <uncovered_a>, last_action_1_hot]
        :param last_agent_action:
        :return:
        """
        if self.last_agent_action is None:
            last_action_one_hot = oneHotLabel(-1, self.num_action)
        else:
            last_action_one_hot = oneHotLabel(self.last_agent_action, self.num_action)
        if "<d>" in self.user_action:
            self.state_maintained[0] = 1
        if "<a>" in self.user_action:
            self.state_maintained[1] = 1
        if "<time>" in self.user_action:
            self.state_maintained[2] = 1
        if "<uncovered_d>" in self.user_action:
            self.state_maintained[3] = 1
            # entity_presence[0] = 1
        if "<uncovered_a>" in self.user_action:
            self.state_maintained[4] = 1
        self.state_maintained[self.num_entity:] = last_action_one_hot

    def step(self, agent_action, sample=False):
        """
        next_state, reward, done, _ = env.step(action)
        :param action:
        :return:
        """
        self.last_agent_action = agent_action
        self.user_action, self.user_acoustic_features = self.user.respond(agent_action, self.state_maintained[:self.num_entity], sample)
        self.maintain_states()
        reward = self.evaluate_cur_move(sample)
        return self.state_maintained, reward, self.done


    def evaluate_cur_move(self, sample=False):
        if self.user_action == "thank you" and (self.state_maintained[0] or self.state_maintained[3]) and \
                (self.state_maintained[1] or self.state_maintained[4]) and self.state_maintained[2]:
            reward = 20
            self.done = True
            self.success = True
        # elif self.user_action == "Good bye!":
        #     reward = 0.1
        #     # if self.turn > self.max
        #     self.done = True
        elif self.user_action == "That's not what I want!":
            reward = -10
            self.done = True
            self.success = False
        # else:
        #     reward = -1
        #     self.done = False
        #     self.success = False
        # return reward
        # elif self.user_action == "But we haven't finish yet!":
        #     reward = -10
        #     self.done = False
        # elif self.user_action == "You already asked/know that!":
        #     reward = -2.5
        #     self.done = False
        #     self.success = False
        
        # elif (self.last_agent_action == 5 or self.last_agent_action == 6) or self.last_agent_action == 7: 
        #     reward = -5
        #     self.done = False
        #     self.success = False

        else:
            if sample:
                u_polite_class = model.predict([self.user_action])
                if self.last_agent_action == 0:
                    bot_reply = "Hello. I'm an automated dialogue system that can give you Bus schedule information. To start with, Please, tell us, where do you want to go?"
                if self.last_agent_action == 1:
                    bot_reply = "Thank you! for providing us your <a>, Please, also tell us Where would you like to leave from?"
                if self.last_agent_action == 2:
                    bot_reply = "Thank you! Your source and destiantion are <a>, <d>. Please, also provide us the time at which you want to travel"
                if self.last_agent_action == 3:
                    bot_reply = "Sorry, for inconvenience. Let me look that up for you. There is a <route> leaving from <departure> to <arrival> at <time>."
                if self.last_agent_action == 4:
                    bot_reply = "Let me look that up for you. Sorry, there is no result that matches your request. We hope, we had been of help"
                if self.last_agent_action == 5:
                    bot_reply = "where do you want to go?"
                if self.last_agent_action == 6:
                    bot_reply = "where are you leaving from?"
                if self.last_agent_action == 7:
                    bot_reply = "what time do you want to travel?"
                b_polite_class = model.predict([bot_reply])
                if (u_polite_class[0] == [0] or u_polite_class[0] == [1]) and (b_polite_class[0] == [2] or b_polite_class[0] == [3]):
                    reward = 2.5
                elif (u_polite_class[0] == [2] or u_polite_class[0] == [3]) and (b_polite_class[0] == [2] or b_polite_class[0] == [3]):
                    reward = 5
                elif (u_polite_class[0] == [2] or u_polite_class[0] == [3]) and (b_polite_class[0] == [0] or b_polite_class[0] == [1]):
                    reward = -2.5
                elif (u_polite_class[0] == [0] or u_polite_class[0] == [1]) and (b_polite_class[0] == [0] or b_polite_class[0] == [1]):
                    reward = -1.5
            else:
                reward = -1
            self.done = False
            self.success = False
        # else:
        #     reward = -1
        #     self.done = False
        #     self.success = False
        return reward
            

    def not_in_sample(self):
        if self.user.total_sample == 0:
            print("total_sample is ", self.user.total_sample)
            return
        print("not in sample ", self.user.not_in_sample/self.user.total_sample)